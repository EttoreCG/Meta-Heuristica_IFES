lado = int(input("Insira o tamanho do lado desejado: "))
area = lado**2
perimetro = lado * 4
diag = lado*(2**(1/2))
print("Lado: ",lado)
print("Área: ",area)
print("Perímetro: ",perimetro)
print("Diagonal: ",diag)
