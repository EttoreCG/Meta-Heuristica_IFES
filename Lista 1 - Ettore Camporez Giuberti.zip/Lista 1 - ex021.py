a = int(input("Digite o valor do cateto a: "))
b = int(input("Digite o valor do cateto b: "))
h = ((a**2)+(b**2))**(1/2)
print("Dado o valor do cateto a: {} e do cateto b: {} temos a hipotenusa {}".format(a, b, h))
