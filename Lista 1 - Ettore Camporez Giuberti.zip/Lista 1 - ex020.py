real = float(input("Insira um número real: "))
raiz = real**(1/2)
print("A raiz quadrada de {} é igual a {}".format(real, raiz))
