import math

raio = float(input("Insira o valor do raio: "))
area = math.pi * (raio**2)
comprimento = 2 * math.pi * raio
print("Dado um raio {} o valor da área é: {}; e do comprimento é: {}".format(raio, area, comprimento))
