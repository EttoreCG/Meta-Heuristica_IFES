d = int(input("Quantos dias de trabalho serão necessários: "))
tf = 80
aser = 55 * d
total = tf + aser
print("A taxa de análise de serviço para {} dia(s) é de {} totalizando um valor a receber de {}".format(d, aser, total))
