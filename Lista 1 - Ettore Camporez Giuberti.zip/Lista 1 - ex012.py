prod = float(input("Insira o valor do seu produto: "))
desc = prod * 0.88
print("Com o nosso desconto de 12% você pagará o valor de: {}".format(desc))
