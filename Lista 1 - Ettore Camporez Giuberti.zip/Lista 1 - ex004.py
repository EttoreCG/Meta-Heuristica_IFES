real = float(input("Digite um número real: "))
quadrado = real**2
print("O resultado do número {} ao quadrado é: {}".format(real, quadrado))

