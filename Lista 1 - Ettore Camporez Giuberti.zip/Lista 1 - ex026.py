

c_x = float(input("Insira a coordenada x do ponto central:"))
c_y = float(input("Insira a coordenada y do ponto central:"))
comprimento = float(input("Insira o comprimento do retângulo:")) 
altura = float(input("Insira a altura do retângulo:"))

vse_x =  c_x - (comprimento/2)
vse_y = c_y + (altura/2)
vie_x = vse_x
vie_y = c_y - (altura/2)
vsd_x = c_x + (comprimento/2)
vsd_y = vse_y
vid_x = vsd_x
vid_y = vie_y

print(f"A partir das coordenadas centrais ({c_x:.2f},{c_y:.2f}), da altura {altura:.2f} e do comprimento {comprimento:.2f}")
print(f"Vértice superior esquerdo: ({vse_x:.2f},{vse_y:.2f})")
print(f"Vértice inferior esquerdo: ({vie_x:.2f},{vie_y:.2f})")
print(f"Vértice superior direito: ({vsd_x:.2f},{vsd_y:.2f})")
print(f"Vértice inferior direito: ({vsd_x:.2f},{vid_y:.2f})")
