x = float(25)
print(x)
