val1 = float(input("Insira o valor do lado a: "))
val2 = float(input("Insira o valor do lado b: "))
val3 = float(input("Insira o valor do lado c: "))
area = 2 * (val1 * val2) + 2 * (val1 * val3) + 2 *(val2 * val3)
volume = val1 * val2 * val3
print("Dados os valores de {} (a), {} (b) e {} (c). Temos uma área total = {} e um volume total = {}".format(val1, val2, val3, area, volume))
