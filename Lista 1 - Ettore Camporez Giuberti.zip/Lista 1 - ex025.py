import math

x = float(input("Insira o valor da coordenada x: "))
y = float(input("Insira o valor da coordenada y: "))
z = float(input("Insira o valor da coordenada z: "))

modulo = math.sqrt(x**2 + y**2 + z**2)

print(f"A partir das coordenadas ({x:.2f},{y:.2f},{z:.2f}) o módulo calculado deste vetor é: {modulo:.2f}")
