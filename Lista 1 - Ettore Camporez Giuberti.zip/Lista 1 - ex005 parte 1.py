#Expressão de conversão entre as escalas de temperatura Celsius e Kelvin: K = C + 273.15
c = float(input("Digite uma temperatura em graus Celsius: "))
k = c + 273.15
print("A sua temperatura {} em graus Celsius equivale à {} em graus Kelvin".format(c, k))
