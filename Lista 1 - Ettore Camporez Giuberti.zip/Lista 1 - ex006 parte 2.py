#Considerando a exprssão de conversão: C = 5.0 * ((F - 32.0)/9.0)
c = float(input("Digite uma temperatura em graus Celsius: "))
f = 32.0 + (c * (9.0/5.0))
print("A temperatura {} em Celsius equivale a {} graus Fahrenheit".format(c, f))
