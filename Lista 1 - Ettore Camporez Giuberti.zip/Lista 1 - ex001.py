num = 145
print(num)
