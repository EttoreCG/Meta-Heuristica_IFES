a = float(input("Digite o lado a do retângulo: "))
b = float(input("Digite o lado b do retângulo: "))

area = a*b
perimetro = 2*a + 2*b
h = ((a**2)+(b**2))**(1/2)

print("A área é: {:.2f}, o perímetro é: {:.2f} e a diagonal é: {:.2f}".format(area,perimetro,h))
