sal_base = float(input("Digite o salário base: R$ "))
grat = sal_base * 0.05
imposto = sal_base * 0.07
sal_receber = sal_base + grat - imposto
print("Você recebeu R${} de gratificação e abateu R${} de impostos. Portanto receberá: R${}".format(grat, imposto, sal_receber))
