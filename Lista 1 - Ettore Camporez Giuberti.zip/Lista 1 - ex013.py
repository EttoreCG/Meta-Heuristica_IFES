sal = float(input("Informe seu salário: "))
aumento = sal * 1.25
print("O seu novo salário é: {}".format(aumento))

