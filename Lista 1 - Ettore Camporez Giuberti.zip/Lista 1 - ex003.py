x = int(input("Digite o primeiro valor: "))
y = int(input("Digite o segundo valor: "))
z = int(input("Digite o terceiro valor: "))
soma = x + y + z
print("A soma dos valores {}, {} e {} é: {}".format(x, y, z, soma))
