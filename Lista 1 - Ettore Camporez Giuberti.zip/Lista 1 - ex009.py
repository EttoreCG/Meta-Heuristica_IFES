nota1 = float(input("Digite sua primeira nota: "))
nota2 = float(input("Digite sua segunda nota: "))
nota3 = float(input("Digite sua terceira nota: "))
nota4 = float(input("Digite sua quarta nota: "))
med = (nota1 + nota2 + nota3 + nota4)/4
print("A média das suas notas foi: {}".format(med))
