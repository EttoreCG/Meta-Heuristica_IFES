import math

h = float(input("Digite a altura do cilindro: "))
raio = float(input("Digite o raio da base do cilindro: "))

area = math.pi*(raio**2)
volume = area*h

print("A área da base do seu cilindro é {:.2f}".format(area))
print("O volume do cilindro é {:.2f}".format(volume))
