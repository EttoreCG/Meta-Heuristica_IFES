import numpy as np
import math

#Input das coordenadas
a = input("Insira as coordenadas x e y do ponto a separadas por vírgula: ")
c = input("\nInsira as coordenadas x e y do ponto c separadas por vírgula: ")

#Separando os inputs 
coordenadas_a = a.split(',')
coordenadas_c = c.split(',')

a_x = float(coordenadas_a[0])
a_y = float(coordenadas_a[1])
c_x = float(coordenadas_c[0])
c_y = float(coordenadas_c[1])

mid_x = (c_x + a_x)/2
mid_y = (c_y + a_y)/2

comprimento = np.linalg.norm(np.array([c_x, c_y]) - np.array([a_x, a_y]))

lado = comprimento/math.sqrt(2)

b_x = a_x
b_y = c_y
d_x = c_x
d_y = a_y

print("O comprimento do segmento de reta AC é: {}\n".format(comprimento))
print(f"Coordenadas ponto médio: ({mid_x:.2f},{mid_y:.2f})\n")
print(f"Se considerarmos ({mid_x:.2f},{mid_y:.2f}) como coordenadas centrais de um quadrado.\n")
print(f"As coordenadas dos vértices desse quadrado são, respectivamente:\nVértice A ({a_x},{a_y})\nVértice B ({b_x},{b_y})\nVértice C ({c_x},{c_y})\nVértice D ({d_x},{d_y})")
