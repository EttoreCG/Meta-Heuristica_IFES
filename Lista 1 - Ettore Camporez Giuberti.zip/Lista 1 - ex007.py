#equação de conversão de km/h para m/s
kmh = float(input("Digite sua velocidade em Km/h: "))
ms = kmh/3.6
print("A velocidade de {} Km/h equivale a {} em m/s".format(kmh, ms))
 