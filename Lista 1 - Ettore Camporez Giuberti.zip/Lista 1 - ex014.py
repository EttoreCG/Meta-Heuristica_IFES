ganhador = int(input("Insira sua posição: "))
if ganhador == 1:
    premio = 780000.00 * 0.46
    print("Sua fatia do premio foi de: {}".format(premio))
elif ganhador == 2:
    premio = 780000.00 * 0.32
    print("Sua fatia do premio foi de: {}".format(premio))
elif ganhador == 3:
    premio = 780000.00 * 0.22
    print("Sua fatia do premio foi de: {}".format(premio))
else:
    print("Não foi dessa vez!")
