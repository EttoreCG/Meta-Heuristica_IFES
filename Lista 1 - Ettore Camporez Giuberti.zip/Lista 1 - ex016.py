total = float(input("Insira o valor total a ser pago: R$"))
desc = total * 0.9
total_parc = total/3
com_vend_vist = desc * 0.05
com_vend_parc = total * 0.05
print("O valor total a pagar com desconto é: {}".format(desc))
print("O valor de cada parcela em 3x sem juros é: {}".format(total_parc))
print("Comissão para venda à vista: {}".format(com_vend_vist))
print("Comissão para venda pacelada: {}".format(com_vend_parc))
