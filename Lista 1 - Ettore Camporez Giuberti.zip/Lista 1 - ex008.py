#equação de conversão: R = G*pi/180.0
#importar o valor pi de uma biblioteca
import math
g = float(input("Digite o valor em graus: "))
r = g * (math.pi/180.0)
print("O valor {} em graus convertido para radianos é: {}".format(g, r))
