import math

def calculo_distancia (x,y):
    distancia = math.sqrt((x**2) + (y**2))
    return distancia

x = float(input("Digite a coordenada X: "))
y = float(input("Digite a coordenada Y: "))

def main():
    distancia = calculo_distancia(x, y)
    print(f"As coordenadas ({x},{y}) tem uma distância igual a {distancia:.2f} do ponto de origem (0,0)")

main()
