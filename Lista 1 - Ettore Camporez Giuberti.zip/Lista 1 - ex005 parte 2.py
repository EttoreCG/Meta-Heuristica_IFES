#Expressão de conversão entre as escalas de temperatura Celsius e Kelvin: K = C + 273.15
k = float(input("Digite sua temperatura de acordo com a escala Kelvin: "))
c = k - 273.15
print("A sua temperatura {} graus em escala Kelvin equivale a {} graus em escala Celsius".format(k, c))
