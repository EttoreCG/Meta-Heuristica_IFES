#Considerando a expressão de cpnversão: C = 5.0 * (F - 32.0)/9.0
f = float(input("Digite uma temperatura em graus Fahrenheit: "))
c = 5.0 * ((f - 32.0)/9.0)
print("A sua temperatura {} em graus Fahrenheit equivale a {} graus Celsius".format(f, c))
