import requests
from bs4 import BeautifulSoup
import re

url = "https://www.google.com/search?q=d%C3%B3lares+em+reais&rlz=1C1GCEA_enBR1070BR1070&oq=d%C3%B3lar&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyDwgCEAAYQxiDARixAxiKBTIKCAMQABixAxiABDINCAQQABiDARixAxiABDIJCAUQABhDGIoFMgYIBhAAGAMyDQgHEAAYgwEYsQMYgAQyDQgIEAAYgwEYsQMYgAQyCggJEAAYsQMYgATSAQgxMzU4ajFqN6gCALACAA&sourceid=chrome&ie=UTF-8"
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0'}
page = requests.get(url, headers=headers)

soup = BeautifulSoup(page.content, 'html.parser')
atributo = {'class':'DFlfde SwHCTb'}
convertion_rate = soup.find("span", atributo)
data_value = float(convertion_rate['data-value'])
real = float(input("Insira o valor em reais: "))
dolar = real/data_value
print("O seu valor em dólares é: {}".format(dolar))
